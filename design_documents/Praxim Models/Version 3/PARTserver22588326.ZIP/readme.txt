US  Your order from www.PARTserver.de on 02/20/2010 is being sent to you:

       SW_MAC, AXK 2035, axk_2035.swb

       Comments, for information on using:

       Solidworks MACRO http://www.cadenas.de/anleitung/Index_AnleitungDB.asp?anr=4&s=1

       The attached file(s) has/have been "zipped" or compressed to make the size of the 
       file smaller, allowing for a quicker download. In order to "unzip" the attached 
       file(s), unzipping software is required. If you do not have this software, then 
       select one of the buttons below to obtain unzipping software from either PKZip� 
       (http://www.pkware.com) or WinZip� (http://www.winzip.com). Both of these 
       products will enable you to "unzip" the attached file(s).

       PARTsolutions offers you free, unlimited access including a CD with many more 
       functions! With PARTsolutions, you also have access free of charge to all standard 
       parts/catalogs at any time via our PARTserver portal. Click here: 
       http://www4.cadenas.de/index_main.asp?sid=2&showcontent=Contact

       Powered by � PARTserver@part-solutions.com



D    Ihre Bestellung bei www.PARTserver.de vom 20.02.2010:

       SW_MAC, AXK 2035, axk_2035.swb
	
       Hinweise zur Benutzung:

       Solidworks MACRO http://www.cadenas.de/anleitung/Index_AnleitungDB.asp?anr=4&s=1

       22588326
       Die beigef�gten Dateien wurden komprimiert ("ZIP"), um einen schnelleren Download
       zu erm�glichen. Um diese Datei(en) zu entpacken wird ein spezielles 
       Dekomprimierungsprogramm ben�tigt. Wenn Sie dieses Programm nicht haben, w�hlen 
       Sie eine der folgenden Links aus, um die Dekomprimierungssoftware herunterzuladen:
       PKZip� (http://www.pkware.com) oder WinZip� (http://www.winzip.com)
       Beide Produkte k�nnen die Dateien entpacken.

       PARTsolutions bietet Ihnen die M�glichkeit eines freien, unlimitierten Zugangs 
       inkl. einer CD L�sung mit wesentlich mehr Funktionen! Mit PARTsolutions stehen 
       Ihnen jederzeit auch alle, aktuellen Normalien/Kataloge �ber unsere PARTserver 
       Portall�sung kostenlos zur Verf�gung. Klicken Sie hier: 
       http://www4.cadenas.de/index_main.asp?sid=1&showcontent=Kontakt
	
       Mit freundlichen Gr��en
       CADENAS GmbH
	
       Powered by � PARTserver@part-solutions.com
       bestnr: 22588326



F     Votre commande chez www.PARTserver.de du 20/02/2010:

       SW_MAC, AXK 2035, axk_2035.swb

       Indications sur l�utilisation:

       Solidworks MACRO http://www.cadenas.de/anleitung/Index_AnleitungDB.asp?anr=4&s=1

       Les fichiers ci-joints ont �t� comprim�s ("ZIP"), pour permettre un t�l�chargement 
       plus rapide. Pour d�comprimer ce(s) fichier(s), un programme de d�compression 
       sp�cial est n�cessaire. Si vous ne poss�dez pas ce programme, choisissez le lien 
       suivant, pour t�l�charger le programme de d�compression:
       PKZip� (http://www.pkware.com) ou WinZip� (http://www.winzip.com)
       Les deux produits peuvent d�comprimer le(s) fichier(s).

       PARTsolutions vous offre la possibilit� d�un libre acc�s illimit�, y compris une 
       solution CD avec largement plus de fonctions! Avec PARTsolutions, toutes les 
       normes et tous les catalogues actuels sont mis � votre disposition gratuitement 
       sur notre solution portail PARTserver. Cliquez ici: 
       http://www4.cadenas.de/index_main.asp?sid=3&showcontent=Contact

       Meilleures salutations
       CADENAS GmbH

       Powered by � PARTserver@part-solutions.com



I      Vostro ordine proveniente da www.PARTserver.de del 20-02-2010:

       SW_MAC, AXK 2035, axk_2035.swb

       Istruzioni d�uso:

       Solidworks MACRO http://www.cadenas.de/anleitung/Index_AnleitungDB.asp?anr=4&s=1

       Il file allegato e� stato compresso (zipped) per diminuire la dimensione del file 
       e permetterne quindi un piu� rapido scaricamento. Per decomprimere (unzip) il file 
       occorre un adeguato programma di decompressione. Se non avete tale programma 
       potete selezionare uno dei link sottostanti per scaricare PKZip� 
       (http://www.pkware.com) o WinZip� (http://www.winzip.com). Entrambi sono in grado 
       di decomprimere il file allegato. 

       PARTsolutions vi offre la possibilit� di un accesso libero e illimitato; � poi 
       prevista una soluzione su CD che include molte pi� funzioni. Con PARTsolutions 
       tutte le parti unificate e le parti commerciali sono messe a disposizione 
       gratuitamente sul nostro portale PARTserver. Fare click qui: 
       http://www4.cadenas.de/index_main.asp?sid=4&showcontent=Contatti

       Con i piu� cordiali saluti,
       CADENAS Gmbh

       Powered by � PARTserver@part-solutions.com



E    Su pedido de www.PARTserver.de de 20-02-2010:

       SW_MAC, AXK 2035, axk_2035.swb

       Indicaciones para el uso:

       Solidworks MACRO http://www.cadenas.de/anleitung/Index_AnleitungDB.asp?anr=4&s=1

       Los archivos adjuntos fueron comprimidos ("ZIP"), para permitir un download mas 
       r�pido.  Para abrir estos archivos es necesario un programa para descomprimir los 
       datos.  Si no tiene este programa, escoja uno de los siguientes links para obtener 
       el programa para descomprimir los datos:  PKZip� (http://www.pkware.com) o 
       WinZip� (http://www.winzip.com) Ambos productos pueden descomprimir los archivos.

       PARTsolutions le ofrece la posibilidad de un acceso libre e ilimitado, inclusive una 
       soluci�n en CD con muchas m�s funciones!  Con PARTsolutions est�n gratuitamente a 
       su disposici�n en cualquier momento todos los cat�logos de normas actuales por medio 
       de nuestra soluci�n portal PARTserver. Haga un clic aqu�: 
       http://www4.cadenas.de/index_main.asp?sid=5&showcontent=Contact

       Atentos saludos
       CADENAS GmbH

       Powered by � PARTserver@part-solutions.com

